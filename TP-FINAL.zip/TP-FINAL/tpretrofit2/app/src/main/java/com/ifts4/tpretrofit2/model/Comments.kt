package com.ifts4.tpretrofit2.model

//Se define la clase de datos Comments.
//Es una clase de datos, identificada por la palabra clave data class, que se utiliza para representar un objeto que contiene comentarios.

data class Comments(
    val postId: Int,
    val id: Int,
    val name: String,
    val email: String,
    val body: String,
)
package com.ifts4.tpretrofit2.service
//Se importan las clases necesarias para el funcionamiento del código, incluyendo Comments, Call y GET de Retrofit.
import com.ifts4.tpretrofit2.model.Comments
import retrofit2.Call
import retrofit2.http.GET

interface ApiService { //Se define la interfaz ApiService, que proporciona los métodos para realizar las llamadas a la API.

    //Aca se declara un método getComments() anotado con @GET que especifica la ruta relativa del endpoint de la API, en este caso, "comments".
    //El método devuelve un objeto Call<List<Comments>>, que representa una solicitud de tipo GET para obtener una lista de comentarios.
    @GET("comments")
    fun getComments(): Call<List<Comments>>
}
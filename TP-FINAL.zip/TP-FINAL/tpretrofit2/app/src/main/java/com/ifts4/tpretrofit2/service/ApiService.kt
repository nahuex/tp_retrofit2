package com.ifts4.tpretrofit2.service

import com.ifts4.tpretrofit2.model.Comments
import retrofit2.Call
import retrofit2.http.GET

interface ApiService {

    @GET("comments")
    fun getComments(): Call<List<Comments>>
}
package com.ifts4.tpretrofit2.viewmodel
//Estas son las importaciones necesarias para las clases y recursos utilizados.
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.ifts4.tpretrofit2.model.Comments
import com.ifts4.tpretrofit2.repository.CommentsRepository
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class HomeViewModel : ViewModel() { //Se declara la clase HomeViewModel que extiende la clase ViewModel

    private val repository = CommentsRepository() //Se crea una instancia de la clase CommentsRepository, que se utilizará para obtener los comentarios de la fuente de datos.

    //Se crea un objeto MutableLiveData llamado "_comments" que contendrá la lista de comentarios. La propiedad pública "comments" expone un LiveData inmutable que puede ser observado desde otras partes del código.
    private val _comments = MutableLiveData<List<Comments>>()
    val comments: LiveData<List<Comments>> get() = _comments

    //La función "getComments()" se encarga de obtener los comentarios llamando al método "getComments()" del objeto repository.
    //La respuesta del servidor se maneja utilizando una interfaz Callback.
    //Cuando se recibe una respuesta exitosa, se actualiza el valor de "_comments" con la lista de comentarios obtenida.
    //En caso de que ocurra un error, la función "onFailure()" está incompleta y arroja una excepción no implementada.
    fun getComments() {
        repository.getComments().enqueue(object : Callback<List<Comments>> {

            override fun onResponse(call: Call<List<Comments>>, response: Response<List<Comments>>) {
                if (response.isSuccessful && response.body() != null) {
                    _comments.value = response.body()
                }
            }

            override fun onFailure(call: Call<List<Comments>>, t: Throwable) {
                TODO("Not yet implemented")
            }

        })
    }

}
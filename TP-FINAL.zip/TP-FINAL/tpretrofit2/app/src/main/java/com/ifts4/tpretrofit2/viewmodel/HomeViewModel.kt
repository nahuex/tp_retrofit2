package com.ifts4.tpretrofit2.viewmodel

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.ifts4.tpretrofit2.model.Comments
import com.ifts4.tpretrofit2.model.CommentsResponse
import com.ifts4.tpretrofit2.repository.CommentsRepository
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class HomeViewModel : ViewModel() {

    private val repository = CommentsRepository()


    private val _comments = MutableLiveData<List<Comments>>()
    val comments: LiveData<List<Comments>> get() = _comments



    fun getComments() {
        repository.getComments().enqueue(object : Callback<List<Comments>> {

            override fun onResponse(call: Call<List<Comments>>, response: Response<List<Comments>>) {
                if (response.isSuccessful && response.body() != null) {
                    _comments.value = response.body()
                }
            }

            override fun onFailure(call: Call<List<Comments>>, t: Throwable) {
                TODO("Not yet implemented")
            }

        })
    }

}
package com.ifts4.tpretrofit2.service
//Se importan las clases y las dependencias necesarias para el funcionamiento de Retrofit
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.util.concurrent.TimeUnit

object RetrofitService { //Se define un objeto singleton llamado RetrofitService

    //Se declara una propiedad mutable llamada INSTANCE de tipo ApiService?, que será una instancia única de la interfaz ApiService.
    //La anotación @Volatile asegura que la propiedad sea visible para todos los hilos y se actualice correctamente en caso de cambios.
    @Volatile
    private var INSTANCE: ApiService? = null

    //Se define una función llamada getInstance() que devuelve una instancia de ApiService.
    //La función utiliza la sincronización para garantizar el acceso único y seguro a la propiedad INSTANCE.
    //Si INSTANCE es nulo, se construye una nueva instancia utilizando la función buildService() y se asigna a INSTANCE.
    fun getInstance(): ApiService {
        synchronized(this) {
            return INSTANCE ?: buildService().also {
                INSTANCE = it
            }
        }
    }

    //La función buildService() crea y configura una instancia de Retrofit.
    //Se especifica la URL base, se configura el cliente de OkHttp con tiempos de espera y se utiliza el convertidor Gson para manejar la conversión de JSON.
    //Finalmente, se crea una instancia de la interfaz ApiService utilizando el objeto retrofit y se devuelve.

    private fun buildService(): ApiService {
        val url = "https://jsonplaceholder.typicode.com/"


        val httpClient: OkHttpClient.Builder =
            OkHttpClient.Builder()
                .connectTimeout(60, TimeUnit.SECONDS)
                .readTimeout(60, TimeUnit.SECONDS)



        val retrofit = Retrofit.Builder()
            .baseUrl(url)
            .client(httpClient.build())
            .addConverterFactory(GsonConverterFactory.create())
            .build()


        return retrofit.create(ApiService::class.java)
    }


}
package com.ifts4.tpretrofit2.repository
//Se importan las clases y las dependencias necesarias para el funcionamiento del código
import com.ifts4.tpretrofit2.model.Comments
import com.ifts4.tpretrofit2.service.ApiService
import com.ifts4.tpretrofit2.service.RetrofitService
import retrofit2.Call

//Se define la clase CommentsRepository, que actúa como una capa de abstracción para interactuar con la API y proporcionar los datos de comentarios.
class CommentsRepository {

    //Se crea una instancia de ApiService utilizando el objeto RetrofitService.getInstance().
    //Esto asegura que se obtenga una única instancia de ApiService configurada correctamente mediante el uso del patrón de diseño Singleton.
    private val retrofit: ApiService = RetrofitService.getInstance()

    //Se define una función llamada getComments() que devuelve un objeto Call<List<Comments>>.
    //Esta función utiliza la instancia de ApiService para llamar al método getComments() definido en la interfaz ApiService.
    //El objeto Call representa una solicitud asíncrona para obtener una lista de comentarios desde la API.
    fun getComments(): Call<List<Comments>> {
        return retrofit.getComments()
    }
}
package com.ifts4.tpretrofit2.repository

import com.ifts4.tpretrofit2.model.Comments
import com.ifts4.tpretrofit2.model.CommentsResponse
import com.ifts4.tpretrofit2.service.ApiService
import com.ifts4.tpretrofit2.service.RetrofitService
import retrofit2.Call

class CommentsRepository {

    private val retrofit: ApiService = RetrofitService.getInstance()


    fun getComments(): Call<List<Comments>> {
        return retrofit.getComments()
    }
}
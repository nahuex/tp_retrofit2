package com.ifts4.tpretrofit2.ui.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.ifts4.tpretrofit2.databinding.ItemCommentsAdapterBinding
import com.ifts4.tpretrofit2.model.Comments

class CommentsAdapter (private val commentsList: List<Comments>) : RecyclerView.Adapter<CommentsAdapter.CommentsViewHolder>() {

    inner class CommentsViewHolder(val binding: ItemCommentsAdapterBinding):
        RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): CommentsAdapter.CommentsViewHolder {
        val binding = ItemCommentsAdapterBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return CommentsViewHolder(binding = binding)
    }

    override fun onBindViewHolder(holder: CommentsAdapter.CommentsViewHolder, position: Int) {
        val comments = commentsList[position]

        holder.binding.txtId.text = comments.id.toString()
        holder.binding.txtName.text = comments.name.toString()
        holder.binding.txtEmail.text = comments.email.toString()
    }

    override fun getItemCount(): Int {
        return commentsList.size
    }
}
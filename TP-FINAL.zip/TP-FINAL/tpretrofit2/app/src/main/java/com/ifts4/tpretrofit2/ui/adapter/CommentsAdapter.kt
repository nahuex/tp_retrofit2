package com.ifts4.tpretrofit2.ui.adapter
//Se importan las clases y dependencias necesarias para el funcionamiento del código
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.ifts4.tpretrofit2.databinding.ItemCommentsAdapterBinding
import com.ifts4.tpretrofit2.model.Comments

//Se define la clase CommentsAdapter que extiende RecyclerView.Adapter y se especifica que está parametrizada con CommentsAdapter.CommentsViewHolder.
//El adaptador se utiliza para enlazar los datos de comentarios con las vistas de los elementos en el RecyclerView.
class CommentsAdapter (private val commentsList: List<Comments>) : RecyclerView.Adapter<CommentsAdapter.CommentsViewHolder>() {

    //Se define la clase interna CommentsViewHolder que extiende RecyclerView.ViewHolder y tiene una propiedad binding de tipo ItemCommentsAdapterBinding.
    //Esta clase se utiliza para mantener las referencias a los elementos de la interfaz de usuario de cada elemento del adaptador.
    inner class CommentsViewHolder(val binding: ItemCommentsAdapterBinding):
        RecyclerView.ViewHolder(binding.root)

    //En el método onCreateViewHolder, se crea y devuelve una instancia de CommentsViewHolder.
    //En este método, se infla la vista del elemento del adaptador utilizando ItemCommentsAdapterBinding y se pasa al constructor de CommentsViewHolder.
    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): CommentsAdapter.CommentsViewHolder {
        val binding = ItemCommentsAdapterBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return CommentsViewHolder(binding = binding)
    }

    //En el método onBindViewHolder, se asignan los datos de comentarios a las vistas correspondientes dentro del CommentsViewHolder.
    //Se accede al elemento de comentarios en la posición dada y se establecen los valores de los campos de texto txtId, txtName y txtEmail en base a las propiedades del objeto Comments.
    override fun onBindViewHolder(holder: CommentsAdapter.CommentsViewHolder, position: Int) {
        val comments = commentsList[position]

        holder.binding.txtId.text = comments.id.toString()
        holder.binding.txtName.text = comments.name.toString()
        holder.binding.txtEmail.text = comments.email.toString()
    }

    //El método getItemCount devuelve el número total de elementos en la lista de comentarios.
    override fun getItemCount(): Int {
        return commentsList.size
    }
}
package com.ifts4.tpretrofit2.model


data class CommentsResponse(
    val results: List<Comments>
)
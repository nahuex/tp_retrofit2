package com.ifts4.tpretrofit2.model

//Se define la clase de datos CommentsResponse.
//Es una clase de datos, identificada por la palabra clave data class, que se utiliza para representar una respuesta de comentarios.
data class CommentsResponse(
    val results: List<Comments> //Representa una lista de comentarios. La lista está compuesta por objetos de la clase Comments.
)

//La clase CommentsResponse se utiliza comúnmente cuando se realiza una solicitud a una API que devuelve una lista de comentarios como respuesta.
//Esta clase encapsula la respuesta y proporciona un acceso conveniente a la lista de comentarios.
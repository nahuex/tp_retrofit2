package com.ifts4.tpretrofit2.ui.adapter
//Importaciones necesarias para las clases y recursos utilizados
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.viewModels
import androidx.recyclerview.widget.LinearLayoutManager
import com.ifts4.tpretrofit2.databinding.FragmentHomeBinding
import com.ifts4.tpretrofit2.viewmodel.HomeViewModel

class HomeFragment : Fragment() { //Se declara la clase HomeFragment, que extiende la clase Fragment.

    //Estas son las propiedades de la clase: homeViewModel, que es una instancia del ViewModel HomeViewModel utilizando la función viewModels(), y binding, que es una referencia al objeto de binding generado a partir del archivo de diseño fragment_home.xml.
    private val HomeViewModel by viewModels<HomeViewModel>()
    private lateinit var binding: FragmentHomeBinding

    //Este es el método onCreateView() que se sobrescribe del Fragment. Se llama cuando el fragmento necesita crear su vista de interfaz de usuario. Recibe un LayoutInflater para inflar el diseño, un ViewGroup que actúa como contenedor y un Bundle opcional para almacenar y recuperar datos.
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = FragmentHomeBinding.inflate(inflater, container, false) //Aca se infla el diseño de la vista del fragmento utilizando el objeto FragmentHomeBinding generado a partir del archivo de diseño fragment_home.xml. El objeto binding se utiliza para acceder a los componentes de la interfaz de usuario en el fragmento.


        binding.rvComments.layoutManager = LinearLayoutManager(requireContext()) //Se configura el LayoutManager del RecyclerView llamado rvComments para que utilice un LinearLayoutManager, lo que permitirá mostrar los elementos en una disposición lineal.
        HomeViewModel.getComments() //Se llama al método getComments() del objeto homeViewModel para obtener los comentarios.
        HomeViewModel.comments.observe(viewLifecycleOwner){CommentsList ->
            binding.rvComments.adapter = CommentsAdapter(CommentsList)
        //Aca se observan los cambios en el LiveData comments del objeto homeViewModel. Cuando los comentarios cambian, se actualiza el adaptador del RecyclerView rvComments con la nueva lista de comentarios.


        }

        //Se devuelve la vista raíz del fragmento, representada por la propiedad root del objeto binding.
        return binding.root
    }


}
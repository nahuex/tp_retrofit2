package com.ifts4.tpretrofit2.ui.adapter

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.viewModels
import androidx.recyclerview.widget.LinearLayoutManager
import com.ifts4.tpretrofit2.databinding.FragmentHomeBinding
import com.ifts4.tpretrofit2.viewmodel.HomeViewModel

class HomeFragment : Fragment() {

    private val HomeViewModel by viewModels<HomeViewModel>()
    private lateinit var binding: FragmentHomeBinding


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = FragmentHomeBinding.inflate(inflater, container, false)


        binding.rvComments.layoutManager = LinearLayoutManager(requireContext())
        HomeViewModel.getComments()
        HomeViewModel.comments.observe(viewLifecycleOwner){CommentsList ->
            binding.rvComments.adapter = CommentsAdapter(CommentsList)


        }


        return binding.root
    }


}